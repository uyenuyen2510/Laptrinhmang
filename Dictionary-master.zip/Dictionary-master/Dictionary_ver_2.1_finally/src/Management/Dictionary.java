package Management;

import java.util.HashMap;

public class Dictionary {
    public static HashMap<String, String> hashMap = new HashMap<>();
    
}
