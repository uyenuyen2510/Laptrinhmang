package folder;

import java.util.ArrayList;

public class Dictionary {
    public static ArrayList<Word> listWord = new ArrayList<>();
            
}
