# java-rmi

Example Java RMI client-server both with and without SSL support.

## License

[MIT License](LICENSE)
