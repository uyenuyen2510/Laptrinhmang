/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12rmi_bai5;

/**
 *
 * @author Pham Tuan
 */
class NoCashAvailableException extends Exception {
    //https://github.com/UB-GEI-SD/Examples/tree/master/RMI
    
}
